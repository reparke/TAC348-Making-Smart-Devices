# PulseCheck Ring

Send 10 minutes of fitness-ring data, with 11 signals, to Google Gemini through a Particle webhook, and show Gemini's answer on the Photon 2's own LED. No wiring is needed.

## Files

| File | What it is |
|------|------------|
| `src/pulsering.cpp` | Your code: TODO 1, 2, and 3, and optional TODO 4 |
| `src/pulsering_setup.h` | The MODE button, the LED, and the ring data. You don't need to change it |
| `src/json_webhook_response_helper.h` | Joins a webhook reply that arrives in pieces. The same file as the weather exercises |
| `pulsering_webhook_body_starter.json` | The JSON body for your webhook, with two blanks: `TODO PROMPT` and `TODO STATES` |

## The data

Each request holds one reading per minute for 10 minutes, for 11 signals:

| Signal | Name in the data | Unit |
|--------|------------------|------|
| Heart rate | `hr_bpm` | beats per minute |
| Steps | `steps_per_min` | steps per minute |
| Heart rate variability | `hrv_ms` | milliseconds. Higher usually means more relaxed |
| Skin temperature | `skin_temp_c` | degrees C |
| Blood oxygen | `spo2_pct` | percent. Normal is 95 or more |
| Breathing rate | `breaths_per_min` | breaths per minute |
| Movement intensity | `motion_g` | g. Near 0 when still |
| Calories burned | `kcal_per_min` | kcal per minute |
| Temperature change from baseline | `temp_delta_c` | degrees C |
| Stress score | `stress` | 0 to 100 |
| Sleep stage | `sleep_stage` | `awake`, `light`, `deep`, or `rem` |

There are five scenarios: resting, walking, a workout, sleep, and something a ring should worry about. They are numbered 1 to 5, and the number does not tell you which is which.

## 1. Get a Gemini API key

Follow [Particle + Gemini Integration](https://makingsmartdevices.com/lectures/weekX/lecture_particle_gemini_integration.html) to create a key. Keep it private: never put it in your code, a commit, a screenshot, or a chat. The free tier is enough.

## 2. Create the webhook

1. Open `pulsering_webhook_body_starter.json` and fill in the two blanks:
   * **TODO PROMPT** your prompt. Cover five parts: Gemini's role, what the 11 signals are and their units, the four states to choose from, when to set `alert`, and how to write `msg` (40 characters at most). Don't use double quotes inside it
   * **TODO STATES** `"sleep", "resting", "walking", "workout"`
2. In the Particle Console, go to **Cloud services**, **Integrations**, **Add new integration**, and choose **Custom Webhook**.
3. Stay on the **Webhook Builder** tab and fill in:

   | Field | Value |
   |-------|-------|
   | Name | `PulseRing` |
   | Event name | `pulsering` |
   | URL | `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent` |
   | Request type | `POST` |
   | Request format | `JSON` |

4. Open **Extra settings**:
   * **JSON data**: choose **Custom**, delete what is there, and paste your whole body file.
   * **HTTP headers**: add the key `x-goog-api-key` with your Gemini API key as the value. The key goes here in the Console only.
   * **Response template**: leave it empty. Your code unpacks Gemini's whole reply.
5. Click **Enable integration**.

To change your prompt later, open the webhook, click **Edit**, and change it under **Extra settings**, **JSON data**.

## 3. Complete the TODOs

Open this folder in Particle Workbench and configure it for your Photon 2. Install two libraries first, the same way as the weather exercises: run **Particle: Install Library** once for `ArduinoJson` and once for `GeminiWebhook`. The starter does not include them, so the compile fails with `ArduinoJson.h: No such file or directory` or `GeminiWebhook.h: No such file or directory` until you do.

`GeminiWebhook` handles sending, waiting, and timeouts. It is not tied to this project: you can install it in any project. Flash after each TODO.

| TODO | Goal | How to check it |
|------|------|-----------------|
| 1 | In `setup()`, subscribe to `hook-response/pulsering` with `onWebhookReply` as the handler. Then subscribe a second time, to `System.deviceID() + "/hook-response/pulsering"`, for webhooks that put the device ID in front of the reply's name | The LED turns white when a request goes out. In the serial monitor you see `Scenario 1 \| Gemini: state= alert=0 msg=""` instead of a timeout |
| 2 | In `onWebhookReply()`, unpack Gemini's reply with `ArduinoJson`, in two steps: take the answer text out of the reply, then unpack that text into `state`, `alert`, and `msg` | The serial monitor line now has real values, for example `state=walking alert=0 msg="Steady walk"` |
| 3 | Show the answer on the LED with `changeLedColor(r, g, b)` and `showAlert()` | The LED turns white, then the color for Gemini's answer |
| 4 (optional) | Write your own safety rule in `safetyRule()` | When it fires, the serial monitor shows "Safety rule: alert" and the LED blinks red |

`safetyRule()` starts with the ready-made `defaultSafetyRule()`, so the alert works even if you skip TODO 4.

## 4. Run it

* The Photon 2 sends the next scenario by itself **every 30 seconds**: 1, 2, 3, 4, 5, then back to 1. To send only when you choose, set `AUTO_SEND_MS` to `0` at the top of `src/pulsering_setup.h`.
* **Tap the MODE button** to send the next scenario right away. Wait 10 seconds between requests.
* To send one scenario again, open your device in the Particle Console and call the function `analyze` with a number from 1 to 5.
* Watch the serial monitor: `particle serial monitor --follow`. Each request prints the scenario number next to Gemini's answer:

  ```
  Sending scenario 1
  Scenario 1 | Gemini: state=walking alert=0 msg="Steady walk, HRV 35 ms"
  ```

* Write down Gemini's `state` and `alert` for each scenario. Your instructor goes over the answers at the end.

| LED | Meaning |
|-----|---------|
| White | Waiting for Gemini |
| Green | Resting |
| Yellow | Walking |
| Orange | Workout |
| Blue | Sleep |
| Blinking red | Alert |
| Magenta | Error: bad reply, webhook error, or timeout |

Before the first request, the LED breathes cyan as usual.

## Free-tier limits

`gemini-3.5-flash-lite` allows 15 requests per minute and 500 per day for each Google project. Sending every 30 seconds uses 120 requests an hour, so unplug the Photon 2 or set `AUTO_SEND_MS` to `0` when you are not testing. The daily limit resets at midnight Pacific time. If you run out (error 429 `RESOURCE_EXHAUSTED`), wait, or switch the model in the webhook URL to `gemini-3.6-flash` for the rest of the day.

## Troubleshooting

| What you see | Cause and fix |
|--------------|---------------|
| White, then magenta after 20 s | No reply reached your code. Check that the webhook exists in your product, its event is `pulsering`, TODO 1 is done with both subscribe lines, and the name in them matches the event name. |
| `state=` is empty in the serial monitor | The reply arrived but TODO 2 is not finished, or the path to the text has a typo. It also happens if the webhook has a response template: clear that field. |
| Magenta right away, "Webhook error" | Gemini rejected the request. Open the webhook in the Console and read the latest error. |
| Error 400 or `API_KEY_INVALID` | The `x-goog-api-key` header is missing or the key is wrong. A 400 "Unknown name" means something other than the body file was pasted into JSON data. |
| Error 404 "no longer available" | The model in the URL was retired. Use `gemini-3.5-flash-lite`. |
| LED breathing magenta, nothing runs | Safe mode: the firmware needs a newer Device OS. Run `particle update` with USB connected, then flash again. |
| A tap on MODE does nothing | It was less than 10 seconds since the last request. The serial monitor shows "Too soon, request skipped". |
