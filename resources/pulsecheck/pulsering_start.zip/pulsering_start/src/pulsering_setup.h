#include "Particle.h"
#include "GeminiWebhook.h"   // library: sending, waiting, timeout, errors (reusable in any project)

/* This is the event your webhook listens for.
   It must match the "event" in your webhook exactly.
*/
const char* EVENT_NAME = "pulsering";

/*
1) SETTINGS ===================================================
  No wiring: this project uses the Photon 2's own RGB LED and its
  MODE button.
  ===============================================================
*/

/* How often the next scenario is sent by itself, in milliseconds.
     30000 = every 30 seconds
     0     = only when you tap the MODE button
*/
const unsigned long AUTO_SEND_MS = 30000;

/*
2) RING DATA ==================================================
  Made-up data for the 11 signals a fitness ring tracks, one
  reading per minute for 10 minutes. There are five scenarios:
  resting, walking, a workout, sleep, and something a ring should
  worry about. Each one is the same numbers every time.

  Only the numbers are sent to Gemini, never the scenario number.
  Your job is to record what Gemini says for each one, then check
  the answer key.

  Decimal values are stored as whole numbers:
  skinTemp10[i] = 335 means 33.5 C.
  ===============================================================
*/
const int MINUTES = 10;                          // 11 signals x 10 minutes fits Particle's 1024-byte limit
const int NUM_SCENARIOS = 5;
const char* SLEEP_NAMES[] = {"awake", "light", "deep", "rem"};

int heartRate[MINUTES];                          // beats per minute
int stepsPerMin[MINUTES];                        // steps per minute
int hrvMs[MINUTES];                              // heart rate variability, ms
int skinTemp10[MINUTES];                         // skin temperature, tenths of a degree C
int spo2[MINUTES];                               // blood oxygen, %
int breaths[MINUTES];                            // breathing rate per minute
int motion100[MINUTES];                          // movement intensity, hundredths of a g
int kcal10[MINUTES];                             // calories burned, tenths of a kcal per minute
int tempDelta10[MINUTES];                        // skin temperature change from baseline, tenths of a degree C
int stress[MINUTES];                             // stress score, 0-100
int sleepStage[MINUTES];                         // 0 awake, 1 light, 2 deep, 3 rem
int scenario = -1;                               // which scenario; the first send is 0 (shown as "Scenario 1")

int noise(int range) { return random(-range, range + 1); }

// Fill the arrays for one scenario. The order is mixed up on purpose.
void loadData() {
    const int SLEEP_CYCLE[] = {1, 1, 2, 2, 2, 1, 3, 3, 1, 1};            // light, deep, REM
    randomSeed(348 + scenario);                                           // the same numbers every time
    for (int i = 0; i < MINUTES; i++) {
        bool spike = i >= MINUTES * 6 / 10;
        int hr = 0, st = 0, hrv = 0, skin = 0, ox = 0, br = 0, mo = 0, kc = 0, td = 0, sr = 0, sl = 0;
        switch (scenario) {
            case 0:                                                       // steady movement
                hr = 98 + noise(6);   st = 100 + noise(10);  hrv = 35 + noise(5);  skin = 330 + noise(2);
                ox = 97 + noise(1);   br = 18 + noise(1);    mo = 35 + noise(8);   kc = 45 + noise(5);
                td = noise(1);        sr = 35 + noise(5);
                break;
            case 1:                                                       // skin warms; sleep stages cycle
                hr = 54 + noise(3);   st = 0;                hrv = 65 + noise(6);  skin = 345 + noise(2);
                ox = 96 + noise(1);   br = 12 + noise(1);    mo = 1 + noise(1);    kc = 10 + noise(1);
                td = noise(1);        sr = 10 + noise(4);    sl = SLEEP_CYCLE[i];
                break;
            case 2:                                                       // heart rate jumps with no movement
                hr = spike ? 145 + noise(5) : 70 + noise(3);
                st = random(0, 4);
                hrv = spike ? 15 + noise(3) : 50 + noise(5);
                skin = 335 + noise(2);
                ox = 97 + noise(1);
                br = spike ? 24 + noise(2) : 14 + noise(1);
                mo = 3 + noise(2);
                kc = spike ? 35 + noise(3) : 13 + noise(1);
                td = noise(1);
                sr = spike ? 85 + noise(5) : 25 + noise(5);
                break;
            case 3:                                                       // quiet and awake
                hr = 68 + noise(4);   st = random(0, 6);     hrv = 50 + noise(6);  skin = 335 + noise(2);
                ox = 97 + noise(1);   br = 14 + noise(1);    mo = 3 + noise(2);    kc = 13 + noise(1);
                td = noise(1);        sr = 25 + noise(5);
                break;
            default:                                                      // everything climbs; HRV drops
                hr = 110 + i * 5 + noise(4);   st = 150 + noise(15);        hrv = 28 - i * 2 + noise(2);
                skin = 332 + i * 2 + noise(1); ox = 96 + noise(1);          br = 22 + i + noise(1);
                mo = 90 + noise(15);           kc = 100 + i * 5 + noise(5); td = i / 2 + noise(1);
                sr = 60 + i * 2 + noise(5);
                break;
        }
        if (mo < 0) mo = 0;                                               // movement cannot be negative
        heartRate[i] = hr;   stepsPerMin[i] = st;   hrvMs[i] = hrv;       skinTemp10[i] = skin;
        spo2[i] = ox;        breaths[i] = br;       motion100[i] = mo;    kcal10[i] = kc;
        tempDelta10[i] = td; stress[i] = sr;        sleepStage[i] = sl;
    }
}

// fixed(335, 1) = "33.5", fixed(-3, 1) = "-0.3", fixed(5, 2) = "0.05"
String fixed(int value, int decimals) {
    if (decimals == 0) return String(value);
    int scale = decimals == 1 ? 10 : 100;
    int a = value < 0 ? -value : value;
    String frac = String(a % scale);
    if (decimals == 2 && a % scale < 10) frac = String("0") + frac;
    return String(value < 0 ? "-" : "") + String(a / scale) + "." + frac;
}

String listOf(const char* name, const int* values, int decimals) {
    String out = String(name) + "=[";
    for (int i = 0; i < MINUTES; i++) {
        out += fixed(values[i], decimals);
        out += i < MINUTES - 1 ? "," : "] ";
    }
    return out;
}

// The text sent to the webhook. No double quotes, so it fits inside the webhook's JSON.
String buildPayload() {
    String out = listOf("hr_bpm", heartRate, 0) + listOf("steps_per_min", stepsPerMin, 0) +
                 listOf("hrv_ms", hrvMs, 0) + listOf("skin_temp_c", skinTemp10, 1) +
                 listOf("spo2_pct", spo2, 0) + listOf("breaths_per_min", breaths, 0) +
                 listOf("motion_g", motion100, 2) + listOf("kcal_per_min", kcal10, 1) +
                 listOf("temp_delta_c", tempDelta10, 1) + listOf("stress", stress, 0);
    out += "sleep_stage=[";
    for (int i = 0; i < MINUTES; i++) {
        out += SLEEP_NAMES[sleepStage[i]];
        out += i < MINUTES - 1 ? "," : "]";
    }
    return out + " interval=1min";
}

/*
2b) READY-MADE SAFETY RULE ====================================
  Gemini sometimes calls a heart rate spike at rest a "workout".
  This returns true when the average heart rate of the last quarter
  of the window is 30+ bpm above the first half while the body
  stays still: steps under 10 per minute and movement under 0.10 g.
  Your safetyRule() can just return this.
  ===============================================================
*/
bool defaultSafetyRule() {
    const int half = MINUTES / 2, tail = MINUTES / 4;
    long early = 0, late = 0, steps = 0, motion = 0;
    for (int i = 0; i < half; i++) early += heartRate[i];               // first half
    for (int i = MINUTES - tail; i < MINUTES; i++) {                      // last quarter
        late += heartRate[i];
        steps += stepsPerMin[i];
        motion += motion100[i];
    }
    bool still = steps / tail < 10 && motion / tail < 10;
    return late / tail - early / half >= 30 && still;                    // heart rate up 30+ while still
}

/*
3) EVENT HANDLER FORWARD DECLARATION =========================
  You need to define this function in pulsering.cpp.
  However, we need a "forward declaration" (the function header)
  as a C++ requirement because it is used below.
  ===============================================================
*/
// Return true when the data needs an alert, whatever Gemini says.
bool safetyRule();

/*
4) LED AND LOG HELPERS ========================================
  Use these in pulsering.cpp
  ===============================================================
*/
bool alertOn = false;
bool ruleFired = false;

// Set the Photon 2's own RGB LED. Each value is 0 to 255.
void changeLedColor(int r, int g, int b) {
    RGB.control(true);                           // take the LED over from Device OS
    RGB.color(r, g, b);
}

// Blink the LED red until the next request.
void showAlert() {
    alertOn = true;
    changeLedColor(255, 0, 0);
}

// true when your safetyRule() raised an alert for the scenario that was just sent
bool safetyRuleFired() { return ruleFired; }

// Print Gemini's answer next to the scenario number in the serial monitor.
void logAnswer(String state, bool alert, String msg) {
    Log.warn("Scenario %d | Gemini: state=%s alert=%d msg=\"%s\"",
             scenario + 1, state.c_str(), alert, msg.c_str());
    if (ruleFired && !alert) Log.warn("Safety rule overrides Gemini: alert on");
}

/*
5) SEND =======================================================
  A tap on the MODE button, the timer, or the "analyze" function
  in the Particle Console sends a scenario to your webhook.
  Reading the reply is your job, in pulsering.cpp.
  ===============================================================
*/
volatile bool buttonPressed = false;
volatile int requested = -1;                     // set by the "analyze" cloud function
unsigned long lastSendMs = 0;

void onModeButton(system_event_t event, int param) { buttonPressed = true; }

// Console: call "analyze" with a scenario number 1 to 5, or leave it blank for the next one.
int analyzeFn(String arg) {
    int n = arg.toInt();
    requested = (n >= 1 && n <= NUM_SCENARIOS) ? n - 1 : NUM_SCENARIOS;
    return requested + 1;
}

// which: 0 to NUM_SCENARIOS - 1 for that scenario, anything else for the next one
void sendData(int which) {
    if (!geminiReady()) {
        Log.warn("Too soon, request skipped");
        return;
    }
    scenario = (which >= 0 && which < NUM_SCENARIOS) ? which : (scenario + 1) % NUM_SCENARIOS;
    loadData();
    ruleFired = safetyRule();
    if (ruleFired) Log.warn("Safety rule: alert");
    String payload = buildPayload();
    Log.warn("Sending scenario %d", scenario + 1);
    Log.info("Sending: %s", payload.c_str());

    alertOn = false;
    lastSendMs = millis();
    changeLedColor(255, 255, 255);               // white = waiting for Gemini
    geminiSend(payload);
}

/*
6) SETUP AND LOOP =============================================
  Call pulsering_setup() in setup() and pulsering_loop() in loop()
  ===============================================================
*/
void pulsering_setup() {
    System.on(button_click, onModeButton);
    Particle.function("analyze", analyzeFn);
    geminiSetup(EVENT_NAME);
}

void pulsering_loop() {
    bool autoDue = AUTO_SEND_MS > 0 && Particle.connected() && geminiReady() &&
                   millis() - lastSendMs >= AUTO_SEND_MS;
    if (requested >= 0) {
        int which = requested;
        requested = -1;
        buttonPressed = false;
        sendData(which);
    } else if (buttonPressed || autoDue) {
        buttonPressed = false;
        sendData(-1);                            // the next scenario
    }

    geminiLoop();                                // reports a timeout if no reply came
    if (alertOn) {
        changeLedColor((millis() / 250) % 2 ? 255 : 0, 0, 0);   // blink red
    }
}

/*-------------------- DEBUG FUNCTIONS -----------------------*/
/*
  printData
      prints the current window to the serial monitor ===
*/
void printData() {
    Serial.println(buildPayload());
}
