#include "Particle.h"

#define ARDUINOJSON_ENABLE_ARDUINO_STRING 1
#include <ArduinoJson.h>

#include "json_webhook_response_helper.h"

SYSTEM_MODE(AUTOMATIC);
SYSTEM_THREAD(ENABLED);
SerialLogHandler logHandler(LOG_LEVEL_WARN);

#include "pulsering_setup.h"
/*
  PulseCheck Ring: fitness-ring data -> Particle webhook -> Gemini -> RGB LED

  Every 30 seconds, or when you tap the MODE button, the Photon 2 sends the
  next 10-minute scenario of made-up fitness-ring data with 11 signals
  (heart rate, steps, HRV, skin temperature, blood oxygen, breathing,
  movement, calories, temperature change, stress, sleep stage). Gemini
  answers with JSON:
    {"state": "workout", "alert": false, "msg": "Great pace, avg 156 bpm!"}
  Your job is to receive that reply, unpack the JSON, and show it on the
  Photon 2's own LED.

  Before you start: install two libraries, the same way as the weather
  exercises. In Workbench: Ctrl/Cmd + Shift + P, "Particle: Install Library".
  Do it once for ArduinoJson and once for GeminiWebhook. The project does
  not compile without them.
    ArduinoJson     unpacks JSON
    GeminiWebhook   sending, waiting, timeout (reusable in any project)

  Files
    pulsering.cpp                    this file: your code
    pulsering_setup.h                the MODE button, the LED, and the ring data
    json_webhook_response_helper.h   joins a webhook reply that arrives in pieces

  No wiring is needed.

  Your job: complete TODO 1, 2, and 3 below. TODO 4 is optional.

  Open the serial monitor to see Gemini's answer for each scenario:
    particle serial monitor --follow

  LED
    white          waiting for Gemini
    green          resting
    yellow         walking
    orange         workout
    blue           sleep
    blinking red   alert
    magenta        error (webhook error, timeout, or an answer we don't know)
*/

/* onWebhookReply()
    Event handler for the webhook's reply. data holds Gemini's whole reply.
    Inside it, as text, is the answer your prompt asked for, for example
    {"state": "workout", "alert": false, "msg": "Great pace!"}
*/
void onWebhookReply(const char* event, const char* data) {
    // A long reply arrives in pieces. This returns "" until all of it is here.
    String fullJson = json_webhook_response_helper(event, data);
    if (fullJson == "") return;
    if (!geminiGotReply()) return;               // stops the timeout; ignores late replies

    String state = "";                           // "resting", "walking", "workout", or "sleep"
    bool alert = false;                          // true or false
    String msg = "";                             // a short note

    /* TODO 2: unpack fullJson into state, alert, and msg
        fullJson is Gemini's whole reply. The answer is a piece of text deep
        inside it, and that text is JSON too, so you unpack twice:

          {
            "candidates": [
              { "content": { "parts": [ { "text": "{\"state\": \"workout\", ...}" } ] } }
            ],
            "usageMetadata": { ... }
          }

        Step 1, the same way as the weather exercises:
          - create a JsonDocument
          - deserializeJson() fullJson into it and keep the DeserializationError
          - if there was an error, call onGeminiError("Reply was not JSON") and return
          - read the text into a String:
              doc["candidates"][0]["content"]["parts"][0]["text"].as<String>()

        Step 2:
          - create a second JsonDocument
          - deserializeJson() that String into it, and check the error again
          - read the three values from the second document, for example
              state = answer["state"].as<String>();
    */


    logAnswer(state, alert, msg);                // print it to the serial monitor
    if (safetyRuleFired()) alert = true;         // the safety rule wins, whatever Gemini says

    /* TODO 3: show the answer on the RGB LED
        alert          blinking red   showAlert();
        "resting"      green          changeLedColor(0, 255, 0);
        "walking"      yellow         changeLedColor(255, 200, 0);
        "workout"      orange         changeLedColor(255, 80, 0);
        "sleep"        blue           changeLedColor(0, 0, 255);
        anything else  magenta        changeLedColor(255, 0, 255);
    */

}

/* onGeminiError()
    Called by the GeminiWebhook library when a request fails: the webhook reported an
    error, no reply came in time, or the publish did not go out.
    You don't need to change this.
*/
void onGeminiError(String why) {
    if (safetyRuleFired()) showAlert();          // still raise the alert without Gemini
    else changeLedColor(255, 0, 255);            // magenta
}

/* safetyRule()
    Gemini sometimes calls a heart rate spike at rest a "workout" and gives
    no alert. Return true to raise the alert yourself, whatever Gemini says.
    Each signal has an array with one value per minute (0 to MINUTES - 1):
    heartRate[i], stepsPerMin[i], hrvMs[i], spo2[i], motion100[i], and the
    others listed in pulsering_setup.h.

    It already uses the ready-made rule, defaultSafetyRule() in
    pulsering_setup.h: the heart rate of the last quarter of the window is
    30+ bpm above the first half while steps and movement stay near zero.

    TODO 4 (optional): replace it with your own rule, for example an alert
    when blood oxygen (spo2) drops below 92. When it fires, the serial
    monitor shows "Safety rule: alert" and the LED blinks red.
*/
bool safetyRule() {
    return defaultSafetyRule();
}

void setup() {
    pulsering_setup();

    Serial.begin(9600);  // begin serial communication

    /* TODO 1: listen for your webhook's reply
        Subscribe to the event "hook-response/pulsering" with onWebhookReply
        as the handler, the same way as the weather exercises.

        Some webhooks put the device ID in front of the reply's name. To cover
        that case, subscribe a second time, to
          System.deviceID() + "/hook-response/pulsering"
    */

}

void loop() {
    pulsering_loop();
}
